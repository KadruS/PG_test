#ifndef QUADRATIC_EQUATION_TESTS_H
#define QUADRATIC_EQUATION_TESTS_H

#include <check.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

#include "../quadratic_equation.h"

Suite *quadratic_equation_tests(void);

#endif // QUADRATIC_EQUATION_TESTS_H