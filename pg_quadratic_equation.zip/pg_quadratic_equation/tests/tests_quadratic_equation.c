#include "tests_quadratic_equation.h"

START_TEST(two_roots) { ck_assert_int_eq(solve_equation(2, -3, 1), TWO_ROOTS); }
END_TEST

START_TEST(one_root) { ck_assert_int_eq(solve_equation(3, -6, 3), ONE_ROOT); }
END_TEST

START_TEST(no_roots) { ck_assert_int_eq(solve_equation(1, 4, 5), NO_ROOTS); }
END_TEST

Suite *quadratic_equation_tests(void) {
  Suite *s = suite_create("\033[44m-=quadratic_equation=-\033[0m");
  TCase *tc = tcase_create("quadratic_equation_tc");

  tcase_add_test(tc, two_roots);
  tcase_add_test(tc, one_root);
  tcase_add_test(tc, no_roots);

  suite_add_tcase(s, tc);
  return s;
}

int main(void) {
  int failed = 0;
  // Insert new test functions in this array
  Suite *s21_matrix_test[] = {quadratic_equation_tests(), NULL};
  int i = 0;
  for (; s21_matrix_test[i] != NULL; i++) {
    SRunner *sr = srunner_create(s21_matrix_test[i]);

    srunner_set_fork_status(sr, CK_NOFORK);
    srunner_run_all(sr, CK_NORMAL);

    failed += srunner_ntests_failed(sr);
    srunner_free(sr);
  }
  printf("\033[30;47m========= ALLTES: %d =========\033[0m\n", i);
  printf("\033[44m========= PASSED: %d =========\033[0m\n", i - failed);
  printf("\033[41m========= FAILED: %d =========\033[0m\n", failed);

  return failed == 0 ? 0 : 1;
}