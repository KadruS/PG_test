#include <math.h>
#include <stdio.h>

int solve_equation(double a, double b, double c);

enum roots { TWO_ROOTS, ONE_ROOT, NO_ROOTS };