#include "quadratic_equation.h"

int solve_equation(double a, double b, double c) {
  int result = NO_ROOTS;
  double discriminant = b * b - 4 * a * c;
  double root_1 = 0;
  double root_2 = 0;
  if (discriminant > 0) {
    root_1 = (-b + sqrt(discriminant)) / (2 * a);
    root_2 = (-b - sqrt(discriminant)) / (2 * a);
    printf("Корни уравнения: %.2f и %.2f\n", root_1, root_2);
    result = TWO_ROOTS;
  } else if (discriminant == 0) {
    root_1 = -b / (2 * a);
    printf("Единственный корень уравнения: %.2f\n", root_1);
    result = ONE_ROOT;
  } else {
    printf("Корней нет!\n");
  }
  return result;
}